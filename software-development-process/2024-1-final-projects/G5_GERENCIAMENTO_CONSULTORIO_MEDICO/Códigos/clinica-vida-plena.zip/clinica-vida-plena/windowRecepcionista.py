import tkinter
import tkinter.messagebox
from tkinter import messagebox
import tkinter as tk
from tkinter import ttk
# import requests


def voltar(root):
    # Chamar a função menuRecepcionista e destruir a janela atual
    root.destroy()
    menuRecepcionista()

def SairSistema(root):
    # Chamar a função menuMedico e destruir a janela atual
    root.destroy()
    from login import Entry
    Entry()    


def mensagem(title="", message="", root=None):
    messagebox.showinfo(title=title, message=message)  
    if root is not None:
        root.destroy()
    menuRecepcionista()

def cadastrar(title="", message="", root=None):
    messagebox.showinfo(title=title, message=message)  
    if root is not None:
        root.destroy()
    menuRecepcionista() 


def CadastrarPaciente(root):
    global rootCadPaciente, namebox, name, cpf, cpfbox, telefone, telefonebox, dataNascimento, dataNascimentobox, endereco, enderecobox, buttonVoltar, buttonCadastrar, buttonSair
    root.destroy()
    rootCadPaciente = tkinter.Tk()
    rootCadPaciente.geometry("600x450")
    rootCadPaciente.configure(background="#98FB98")
    rootCadPaciente.resizable(width=False, height=False)
    rootCadPaciente.title("Clínica Vida Plena - Cadastro de Paciente")
    
    topframe = tkinter.Frame(rootCadPaciente, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootCadPaciente, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Cadastro de Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    name = tkinter.Label(bottomframe, text="Nome Completo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=60)
    namebox.place(x=180, y=20)  # Define a posição do 'Entry' no 'bottomframe'

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=13)
    cpfbox.place(x=90, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    telefone = tkinter.Label(bottomframe, text="Contato:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    telefone.place(x=177, y=70)  # Define a posição do label 'Telefone' no 'bottomframe'
    telefonebox = tkinter.Entry(bottomframe, width=12)
    telefonebox.place(x=242, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    dataNascimento = tkinter.Label(bottomframe, text="Data de Nascimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    dataNascimento.place(x=330, y=70)  
    dataNascimentobox = tkinter.Entry(bottomframe, width=10)
    dataNascimentobox.place(x=480, y=70)  
 
    endereco = tkinter.Label(bottomframe, text="Endereço:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    endereco.place(x=50, y=120)  
    enderecobox = tkinter.Entry(bottomframe, width=68)
    enderecobox.place(x=130, y=120)  

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootCadPaciente))
    buttonVoltar.place(x=305,y=350)
    buttonCadastrar = tkinter.Button(bottomframe, text="Cadastrar",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: cadastrar("", "Cadastro Realizado !",rootCadPaciente))
    buttonCadastrar.place(x=360,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootCadPaciente))
    buttonSair.place(x=435,y=350)
    rootCadPaciente.mainloop()


def EditarPaciente(root):
    global rootEditPaciente, namebox, name, cpf, cpfbox, telefone, telefonebox, dataNascimento, dataNascimentobox, endereco, enderecobox, buttonVoltar, buttonAtualCadastro, buttonSair
    root.destroy()
    rootEditPaciente = tkinter.Tk()
    rootEditPaciente.geometry("600x450")
    rootEditPaciente.configure(background="#98FB98")
    rootEditPaciente.resizable(width=False, height=False)
    rootEditPaciente.title("Clínica Vida Plena - Atualização Paciente")
    
    topframe = tkinter.Frame(rootEditPaciente, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootEditPaciente, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Atualização Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    name = tkinter.Label(bottomframe, text="Nome Completo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=57)
    namebox.place(x=180, y=20)  # Define a posição do 'Entry' no 'bottomframe'

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=18)
    cpfbox.place(x=95, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    telefone = tkinter.Label(bottomframe, text="Telefone:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    telefone.place(x=50, y=120)  # Define a posição do label 'Telefone' no 'bottomframe'
    telefonebox = tkinter.Entry(bottomframe, width=15)
    telefonebox.place(x=120, y=120)  # Define a posição do 'Entry' no 'bottomframe'

    dataNascimento = tkinter.Label(bottomframe, text="Data de Nascimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    dataNascimento.place(x=50, y=170)  
    dataNascimentobox = tkinter.Entry(bottomframe, width=50)
    dataNascimentobox.place(x=200, y=170)  
 
    endereco = tkinter.Label(bottomframe, text="Endereço:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    endereco.place(x=50, y=220)  
    enderecobox = tkinter.Entry(bottomframe, width=57)
    enderecobox.place(x=130, y=220)  

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootEditPaciente))
    buttonVoltar.place(x=260,y=350)
    buttonAtualCadastro = tkinter.Button(bottomframe, text="Atualizar cadastro",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: cadastrar("", "Cadastro Atualizado !",rootEditPaciente))
    buttonAtualCadastro.place(x=315,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=rootEditPaciente.destroy)
    buttonSair.place(x=435,y=350)
    rootEditPaciente.mainloop()

def ExcluirPaciente(root):
    global rootExcPaciente
    root.destroy()
    rootExcPaciente = tkinter.Tk()
    rootExcPaciente.geometry("600x450")
    rootExcPaciente.configure(background="#98FB98")
    rootExcPaciente.resizable(width=False, height=False)
    rootExcPaciente.title("Clínica Vida Plena - Ediçao de Paciente")
    
    topframe = tkinter.Frame(rootExcPaciente, bg='#98FB98')
    topframe.place(x=0, y=0, width=600, height=50)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootExcPaciente, bg='#98FB98')
    bottomframe.place(x=0, y=50, width=600, height=350)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Ediçao de Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(x=20, y=10)  # Posiciona o label dentro do topframe

    rootExcPaciente.mainloop()

def VisualizarPaciente(root):
    global rootConsPaciente, buttonVoltar, buttonEditar, buttonExcluir, buttonSair, buttonPesquisar
    root.destroy()
    rootConsPaciente =tkinter.Tk()
    rootConsPaciente.geometry("600x450")
    rootConsPaciente.configure(background="#98FB98")
    rootConsPaciente.resizable(width=False, height=False)
    rootConsPaciente.title("Clínica Vida Plena - Consulta de Paciente")
    
    topframe = tkinter.Frame(rootConsPaciente, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootConsPaciente, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Consulta de Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(relx=0.5, rely=0.5, anchor='center')
    
    rootConsPaciente.title("Clínica Vida Plena - Consulta de Paciente")

    name = tkinter.Label(bottomframe, text="Nome:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=30)
    namebox.place(x=120, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=305, y=70)  # Define a posição do label 'Matrícula' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=15)
    cpfbox.place(x=350, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    buttonPesquisar = tkinter.Button(bottomframe, text="Pesquisar",font='Arial 9 bold',command="")
    buttonPesquisar.place(x=450,y=64)

    columns = ("Nome Paciente", "CPF","Data de Nascimento")
    tree = ttk.Treeview(bottomframe, columns=columns, show='headings')
    
    tree.column("Nome Paciente", width=120)
    tree.column("CPF", width=20)
    tree.column("Data de Nascimento", width=20)
   
    tree.heading("Nome Paciente", text="Nome Paciente")
    tree.heading("CPF", text="CPF")
    tree.heading("Data de Nascimento", text="Data de Nascimento")
    tree.place(x=50, y=110, width=500, height=200)

    # Exemplo de inserção de dados na tabela

    tree.insert("", "end", values=("Pedro Souza", "12345678901", "02/05/1967"))
    tree.insert("", "end", values=("Maria Silva", "23456789012", "08/04/1996"))
    tree.insert("", "end", values=("Carlos Oliveira", "34567890123", "04/12/1947"))
    tree.insert("", "end", values=("Lucas Pereira", "45678901234", "19/07/2008"))

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootConsPaciente))
    buttonVoltar.place(x=160,y=350)  # diminuiu o valor de x
    
    buttonEditar = tkinter.Button(bottomframe, text="Editar",font='Arial 8 bold', command = lambda:EditarPaciente(rootConsPaciente))
    buttonEditar.place(x=210,y=350)  # diminuiu o valor de x
    
    buttonExcluir = tkinter.Button(bottomframe, text="Excluir",font='Arial 8 bold', command=lambda: mensagem("", "Paciente Excluído !", rootConsPaciente))
    buttonExcluir.place(x=260,y=350)  # diminuiu o valor de x
    
    buttonCadastrarAtendimento = tkinter.Button(bottomframe, text="Cadastrar Atendimento", font='Arial 8 bold', command=lambda:CadastrarAtendimento(rootConsPaciente))
    buttonCadastrarAtendimento.place(x=310,y=350)  # diminuiu o valor de x
    
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold',bg='#FF0000' , fg='#FFFFFF', command=lambda:SairSistema(rootConsPaciente))
    buttonSair.place(x=460, y=350)  # diminuiu o valor de x

    rootConsPaciente.mainloop()


def CadastrarAtendimento(root):
    global rootCadAtendimento, cpf, cpfbox, idAtend, idAtendbox, data, databox, sexo, sexobox, hora, horabox, crm, crmbox, especialidade, especialidadebox, buttonVoltar, buttonCadastrar, buttonSair
    root.destroy()
    rootCadAtendimento = tkinter.Tk()
    rootCadAtendimento.geometry("600x450")
    rootCadAtendimento.configure(background="#98FB98")
    rootCadAtendimento.resizable(width=False, height=False)
    rootCadAtendimento.title("Clínica Vida Plena - Agendamento de Atendimento")
    
    topframe = tkinter.Frame(rootCadAtendimento, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootCadAtendimento, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCadAted = tkinter.Label(topframe, text="Agendamento de Atendimento", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCadAted.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    idAtend = tkinter.Label(bottomframe, text="Id_Atendimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    idAtend.place(x=50, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    idAtendbox = tkinter.Entry(bottomframe, width=5)
    idAtendbox.place(x=170, y=20)  # Define a posição do 'Entry' no 'bottomframe'

    data = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    data.place(x=225, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    databox = tkinter.Entry(bottomframe, width=15)
    databox.place(x=270, y=20)  # Define a posição do 'Entry' no 'bottomframe'
        
    hora = tkinter.Label(bottomframe, text="Hora:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    hora.place(x=377, y=20)  
    horabox = tkinter.Entry(bottomframe, width=15)
    horabox.place(x=427, y=20)  

    cpf = tkinter.Label(bottomframe, text="CPF do Paciente:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=15)
    cpfbox.place(x=185, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    sexo = tkinter.Label(bottomframe, text="Sexo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    sexo.place(x=50, y=120)  
    sexobox = tkinter.Entry(bottomframe, width=15)
    sexobox.place(x=100, y=120)  
        
    crm = tkinter.Label(bottomframe, text="CRM:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    crm.place(x=320, y=70)
    crmbox = tkinter.Entry(bottomframe, width=19)
    crmbox.place(x=370, y=70)
            

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootCadAtendimento))
    buttonVoltar.place(x=305,y=350)
    buttonCadastrar = tkinter.Button(bottomframe, text="Cadastrar",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: cadastrar("", "Cadastro Realizado !",rootCadAtendimento))
    buttonCadastrar.place(x=360,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootCadAtendimento))
    buttonSair.place(x=435,y=350)
    rootCadAtendimento.mainloop()

def ConsultarAtendimento(root):
    global rootConsAtendimento, buttonVoltar,buttonEditar, buttonExcluir, buttonSair,buttonPesquisar
    root.destroy()
    rootConsAtendimento =tkinter.Tk()
    rootConsAtendimento.geometry("600x450")
    rootConsAtendimento.configure(background="#98FB98")
    rootConsAtendimento.resizable(width=False, height=False)
    rootConsAtendimento.title("Clínica Vida Plena - Atendimentos")
    
    topframe = tkinter.Frame(rootConsAtendimento, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootConsAtendimento, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Atendimentos", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(relx=0.5, rely=0.5, anchor='center')
    
    rootConsAtendimento.title("Clínica Vida Plena - Atendimentos")
    

    name = tkinter.Label(bottomframe, text="Nome:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=30)
    namebox.place(x=120, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    buttonPesquisar = tkinter.Button(bottomframe, text="Pesquisar",font='Arial 12 bold',command="")
    buttonPesquisar.place(x=320,y=65)


    columns = ("ID", "Nome", "Data", "Hora")
    tree = ttk.Treeview(bottomframe, columns=columns, show='headings')
    
    tree.column("ID", width=30)
    tree.column("Nome", width=150)
    tree.column("Data", width=60)
    tree.column("Hora", width=100)

    
    tree.heading("ID", text="ID")
    tree.heading("Nome", text="Nome")
    tree.heading("Data", text="Data")
    tree.heading("Hora", text="Hora")
    tree.place(x=50, y=100, width=500, height=200)

    # Exemplo de inserção de dados na tabela
    tree.insert("", "end", values=("1", "Paciente A", "2024-06-11", "10:00"))
    tree.insert("", "end", values=("2", "Paciente B", "2024-06-12", "11:00"))



    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootConsAtendimento))
    buttonVoltar.place(x=280,y=350)
    buttonEditar = tkinter.Button(bottomframe, text="Editar",font='Arial 8 bold', command = lambda:EditarAtendimento(rootConsAtendimento))
    buttonEditar.place(x=330,y=350)
    buttonExcluir = tkinter.Button(bottomframe, text="Excluir",font='Arial 8 bold', command=lambda: mensagem("", "Atendimento Excluído !",rootConsAtendimento))
    buttonExcluir.place(x=380,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold',bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootConsAtendimento))
    buttonSair.place(x=435,y=350)
    rootConsAtendimento.mainloop()

def EditarAtendimento(root):
    global rootEditAtendimento, cpf, cpfbox, idAtend, idAtendbox, data, databox, sexo, sexobox, hora, horabox, crm, crmbox, especialidade, especialidadebox, buttonVoltar, buttonAtualCadastro, buttonSair
    
    root.destroy()
    rootEditAtendimento = tkinter.Tk()
    rootEditAtendimento.geometry("600x450")
    rootEditAtendimento.configure(background="#98FB98")
    rootEditAtendimento.resizable(width=False, height=False)
    rootEditAtendimento.title("Clínica Vida Plena - Atualizar Atendimento")
    
    topframe = tkinter.Frame(rootEditAtendimento, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootEditAtendimento, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingEdit = tkinter.Label(topframe, text="Atualizar Atendimento", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingEdit.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    idAtend = tkinter.Label(bottomframe, text="Id_Atendimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    idAtend.place(x=50, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    idAtendbox = tkinter.Entry(bottomframe, width=5)
    idAtendbox.place(x=170, y=20)  # Define a posição do 'Entry' no 'bottomframe'

    data = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    data.place(x=225, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    databox = tkinter.Entry(bottomframe, width=15)
    databox.place(x=270, y=20)  # Define a posição do 'Entry' no 'bottomframe'
        
    hora = tkinter.Label(bottomframe, text="Hora:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    hora.place(x=377, y=20)  
    horabox = tkinter.Entry(bottomframe, width=15)
    horabox.place(x=427, y=20)  

    cpf = tkinter.Label(bottomframe, text="CPF do Paciente:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=15)
    cpfbox.place(x=185, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    sexo = tkinter.Label(bottomframe, text="Sexo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    sexo.place(x=50, y=120)  
    sexobox = tkinter.Entry(bottomframe, width=15)
    sexobox.place(x=100, y=120)  
        
    crm = tkinter.Label(bottomframe, text="CRM:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    crm.place(x=320, y=70)
    crmbox = tkinter.Entry(bottomframe, width=19)
    crmbox.place(x=370, y=70)

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar", font='Arial 8 bold', command=lambda: voltar(rootEditAtendimento))
    buttonVoltar.place(x=260, y=350)
    buttonAtualCadastro = tkinter.Button(bottomframe, text="Atualizar Cadastro", font='Arial 8 bold', bg='#00FF00', fg='#006400', command=lambda: cadastrar("Cadastro", "Atendimento Atualizado !",rootEditAtendimento))
    buttonAtualCadastro.place(x=315, y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta", font='Arial 8 bold', bg='#FF0000', fg='#FFFFFF', command=rootEditAtendimento.destroy)
    buttonSair.place(x=435, y=350)

    rootEditAtendimento.mainloop()

def ExcluirAtendimento(root):
    global rootExcFunc, buttonFunc
    root.destroy()
    rootExcFunc = tkinter.Tk()
    rootExcFunc.geometry("600x450")
    rootExcFunc.configure(background="#98FB98")
    rootExcFunc.resizable(width=False, height=False)
    rootExcFunc.title("Clínica Vida Plena - Ediçao de Paciente")
    
    topframe = tkinter.Frame(rootExcFunc, bg='#98FB98')
    topframe.place(x=0, y=0, width=600, height=50)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootExcFunc, bg='#98FB98')
    bottomframe.place(x=0, y=50, width=600, height=350)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Ediçao de Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(x=20, y=10)  # Posiciona o label dentro do topframe

    rootExcFunc.mainloop()

def menuRecepcionista():
    global rootRecepcionista, buttonCadPaciente, buttonConsAtendimentos, buttonConsPaciente, buttonExit
   
    rootRecepcionista =tkinter.Tk()
    rootRecepcionista.geometry("600x450")
    rootRecepcionista.configure(background="#98FB98")
    rootRecepcionista.resizable(width=False, height=False)
    rootRecepcionista.title("Clínica Vida Plena - Recepcionista")
    
    topframe = tkinter.Frame(rootRecepcionista,bg='#98FB98')
    topframe.pack(pady=10)

    bottomframe = tkinter.Frame(rootRecepcionista,bg='#98FB98')
    bottomframe.pack(pady=10)
   
    heading = tkinter.Label(topframe, text= "Pacientes e Atendimentos", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
   

    buttonCadPaciente = tkinter.Button(bottomframe, text="Cadastrar Paciente",font='Arial 12 bold',command=lambda: CadastrarPaciente(rootRecepcionista))
    buttonConsPaciente = tkinter.Button(bottomframe, text="Visualizar Paciente",font='Arial 12 bold',command=lambda:VisualizarPaciente(rootRecepcionista))
    buttonConsAtendimentos = tkinter.Button(bottomframe, text="Visualizar Atendimentos",font='Arial 12 bold',command=lambda: ConsultarAtendimento(rootRecepcionista))

    buttonExit = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootRecepcionista)) 
    heading.pack(pady=5)
  
    buttonCadPaciente.pack(pady=10)
    buttonConsPaciente.pack(pady=10)
    buttonConsAtendimentos.pack(pady=10)
    buttonExit.pack(pady=30)

    rootRecepcionista.title("Clínica Vida Plena - Recepcionista")
    rootRecepcionista.mainloop()

def add_patient_to_backend(name, dob):
    url = '/patients'
    patient_data = {'name': name, 'dob': dob}
    response = requests.post(url, json=patient_data)
    if response.status_code == 201:
        print("Patient added successfully")
    else:
        print("Failed to add patient")


def fetch_appointments_from_backend():
    url = '/appointments'
    response = requests.get(url)
    if response.status_code == 200:
        appointments = response.json()

    else:
        print("Failed to fetch appointments")


# if __name__ == "__main__":
#     menuRecepcionista()