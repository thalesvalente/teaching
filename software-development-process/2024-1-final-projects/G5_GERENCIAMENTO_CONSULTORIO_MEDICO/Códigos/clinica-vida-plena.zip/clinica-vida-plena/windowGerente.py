import tkinter
import sqlite3
import tkinter.messagebox
from tkinter import messagebox

def voltar(root):
    # Chamar a função menuGerente e destruir a janela atual
    root.destroy()
    menuGerente()

def SairSistema(root):
    # Chamar a função menuMedico e destruir a janela atual
    root.destroy()
    from main import Entry
    Entry()    
def mensagem(title="", message="", root=None):
    messagebox.showinfo(title=title, message=message)  
    if root is not None:
        root.destroy()
    menuGerente() 

def CadastrarFunc(root):       
    global rootCadFunc, namebox, name, cpf, cpfbox, matricula, matriculabox, cargo, userName, userNamebox, password,passwordbox, salary, salarybox, comissao, comissaobox, area, areabox, crm, crmbox, especialidade, especialidadebox, ramal, ramalbox, buttonVoltar,buttonCadastrar, buttonSair
    root.destroy()
    rootCadFunc = tkinter.Tk()
    rootCadFunc.geometry("600x450")
    rootCadFunc.configure(background="#98FB98")
    rootCadFunc.resizable(width=False, height=False)
    rootCadFunc.title("Clínica Vida Plena - Cadastro de Funcionario")
    
    topframe = tkinter.Frame(rootCadFunc, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootCadFunc, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Cadastro de Funcionario", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    name = tkinter.Label(bottomframe, text="Nome Completo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=20)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=57)
    namebox.place(x=180, y=20)  # Define a posição do 'Entry' no 'bottomframe'

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=18)
    cpfbox.place(x=95, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    matricula = tkinter.Label(bottomframe, text="Matricula:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    matricula.place(x=210, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    matriculabox = tkinter.Entry(bottomframe, width=18)
    matriculabox.place(x=285, y=70)  # Define a posição do 'Entry' no 'bottomframe'
    
    cargo_var = tkinter.StringVar()
    cargo_var.set("Cargo")
    cargo = tkinter.OptionMenu(bottomframe, cargo_var, "Gerente", "Recepcionista", "Médico(a)")
    cargo.place(x=450, y=65)
    
    salary = tkinter.Label(bottomframe, text="Salário:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    salary.place(x=50, y=120)  
    salarybox = tkinter.Entry(bottomframe, width=15)
    salarybox.place(x=110, y=120)  

    userName = tkinter.Label(bottomframe, text="Usuário:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    userName.place(x=210, y=120)  
    userNamebox = tkinter.Entry(bottomframe, width=15)
    userNamebox.place(x=275, y=120)  

    password = tkinter.Label(bottomframe, text="Senha:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    password.place(x=370, y=120)  
    passwordbox = tkinter.Entry(bottomframe, width=15)
    passwordbox.place(x=430, y=120)  
  
    comissao = tkinter.Label(bottomframe, text="Comissão:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    comissao.place(x=50, y=170)  
    comissaobox = tkinter.Entry(bottomframe, width=15)
    comissaobox.place(x=125, y=170)  

    area = tkinter.Label(bottomframe, text="Área de Atuação:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    area.place(x=225, y=170)  
    areabox = tkinter.Entry(bottomframe, width=28)
    areabox.place(x=350, y=170)  

    crm = tkinter.Label(bottomframe, text="CRM:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    crm.place(x=50, y=220)  
    crmbox = tkinter.Entry(bottomframe, width=19)
    crmbox.place(x=100, y=220)  

    especialidade = tkinter.Label(bottomframe, text="Especialidade:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    especialidade.place(x=225, y=220)  
    especialidadebox = tkinter.Entry(bottomframe, width=31)
    especialidadebox.place(x=330, y=220)  

    turno = tkinter.Label(bottomframe, text="Turno:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    turno.place(x=50, y=270)  
    turnobox = tkinter.Entry(bottomframe, width=19)
    turnobox.place(x=100, y=270)  

    ramal = tkinter.Label(bottomframe, text="Ramal Telefônico:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    ramal.place(x=225, y=270)  
    ramalbox = tkinter.Entry(bottomframe, width=27)
    ramalbox.place(x=355, y=270)  


    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootCadFunc))
    buttonVoltar.place(x=305,y=350)
    buttonCadastrar = tkinter.Button(bottomframe, text="Cadastrar",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: mensagem("", "Cadastro Realizado !",rootCadFunc))
    buttonCadastrar.place(x=360,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootCadFunc))
    buttonSair.place(x=435,y=350)
    rootCadFunc.mainloop()

def ExcluirFunc(root):
    global rootExcFunc, buttonFunc
    root.destroy()
    rootExcFunc = tkinter.Tk()
    rootExcFunc.geometry("600x450")
    rootExcFunc.configure(background="#98FB98")
    rootExcFunc.resizable(width=False, height=False)
    rootExcFunc.title("Clínica Vida Plena - Ediçao de Funcionario")
    
    topframe = tkinter.Frame(rootExcFunc, bg='#98FB98')
    topframe.place(x=0, y=0, width=600, height=50)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootExcFunc, bg='#98FB98')
    bottomframe.place(x=0, y=50, width=600, height=350)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Ediçao de Funcionario", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(x=20, y=10)  # Posiciona o label dentro do topframe

    rootExcFunc.mainloop()


def EditarFunc(root):
    global rootEditFunc, namebox, cpfbox, matriculabox, cargo_var, userNamebox, passwordbox, salarybox, comissaobox, areabox, crmbox, especialidadebox, turnobox, ramalbox, buttonVoltar, buttonAtualCadastro, buttonSair
    
    root.destroy()
    rootEditFunc = tkinter.Tk()
    rootEditFunc.geometry("600x450")
    rootEditFunc.configure(background="#98FB98")
    rootEditFunc.resizable(width=False, height=False)
    rootEditFunc.title("Clínica Vida Plena - Edição de Cadastro de Funcionario")
    
    topframe = tkinter.Frame(rootEditFunc, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootEditFunc, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingEdit = tkinter.Label(topframe, text="Edição de Cadastro de Funcionario", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingEdit.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    name = tkinter.Label(bottomframe, text="Nome Completo:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=20)
    namebox = tkinter.Entry(bottomframe, width=57)
    namebox.place(x=180, y=20)

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=50, y=70)
    cpfbox = tkinter.Entry(bottomframe, width=18)
    cpfbox.place(x=95, y=70)

    matricula = tkinter.Label(bottomframe, text="Matricula:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    matricula.place(x=210, y=70)
    matriculabox = tkinter.Entry(bottomframe, width=18)
    matriculabox.place(x=285, y=70)

    cargo_var = tkinter.StringVar()
    cargo_var.set("Cargo")
    cargo = tkinter.OptionMenu(bottomframe, cargo_var, "Gerente", "Recepcionista", "Médico(a)")
    cargo.place(x=450, y=65)

    salary = tkinter.Label(bottomframe, text="Salário:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    salary.place(x=50, y=120)
    salarybox = tkinter.Entry(bottomframe, width=15)
    salarybox.place(x=110, y=120)

    userName = tkinter.Label(bottomframe, text="Usuário:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    userName.place(x=210, y=120)
    userNamebox = tkinter.Entry(bottomframe, width=15)
    userNamebox.place(x=275, y=120)

    password = tkinter.Label(bottomframe, text="Senha:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    password.place(x=370, y=120)
    passwordbox = tkinter.Entry(bottomframe, width=15)
    passwordbox.place(x=430, y=120)

    comissao = tkinter.Label(bottomframe, text="Comissão:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    comissao.place(x=50, y=170)
    comissaobox = tkinter.Entry(bottomframe, width=15)
    comissaobox.place(x=125, y=170)

    area = tkinter.Label(bottomframe, text="Área de Atuação:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    area.place(x=225, y=170)
    areabox = tkinter.Entry(bottomframe, width=28)
    areabox.place(x=350, y=170)

    crm = tkinter.Label(bottomframe, text="CRM:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    crm.place(x=50, y=220)
    crmbox = tkinter.Entry(bottomframe, width=19)
    crmbox.place(x=100, y=220)

    especialidade = tkinter.Label(bottomframe, text="Especialidade:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    especialidade.place(x=225, y=220)
    especialidadebox = tkinter.Entry(bottomframe, width=31)
    especialidadebox.place(x=330, y=220)

    turno = tkinter.Label(bottomframe, text="Turno:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    turno.place(x=50, y=270)
    turnobox = tkinter.Entry(bottomframe, width=19)
    turnobox.place(x=100, y=270)

    ramal = tkinter.Label(bottomframe, text="Ramal Telefônico:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    ramal.place(x=225, y=270)
    ramalbox = tkinter.Entry(bottomframe, width=27)
    ramalbox.place(x=355, y=270)

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar", font='Arial 8 bold', command=lambda: voltar(rootEditFunc))
    buttonVoltar.place(x=260, y=350)
    buttonAtualCadastro = tkinter.Button(bottomframe, text="Atualizar Cadastro", font='Arial 8 bold', bg='#00FF00', fg='#006400', command=lambda: mensagem("Cadastro", "Cadastro Atualizado !",rootEditFunc))
    buttonAtualCadastro.place(x=315, y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta", font='Arial 8 bold', bg='#FF0000', fg='#FFFFFF', command=lambda: SairSistema(rootEditFunc))
    buttonSair.place(x=435, y=350)

    rootEditFunc.mainloop()
       
def ConsultarFunc(root):
    global rootConsFunc, buttonVoltar,buttonEditar, buttonExcluir, buttonSair,buttonPesquisar
    root.destroy()
    rootConsFunc =tkinter.Tk()
    rootConsFunc.geometry("600x450")
    rootConsFunc.configure(background="#98FB98")
    rootConsFunc.resizable(width=False, height=False)
    rootConsFunc.title("Clínica Vida Plena - Consulta de Funcionario")
    
    topframe = tkinter.Frame(rootConsFunc, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootConsFunc, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Consulta de Funcionario", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(relx=0.5, rely=0.5, anchor='center')
    
    rootConsFunc.title("Clínica Vida Plena - Consulta de Funcionario")
    

    name = tkinter.Label(bottomframe, text="Nome:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=30)
    namebox.place(x=120, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    cpf = tkinter.Label(bottomframe, text="CPF:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    cpf.place(x=305, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    cpfbox = tkinter.Entry(bottomframe, width=30)
    cpfbox.place(x=350, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    buttonPesquisar = tkinter.Button(bottomframe, text="Pesquisar",font='Arial 12 bold',command="")
    buttonPesquisar.place(x=225,y=120)


    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootConsFunc))
    buttonVoltar.place(x=280,y=350)
    buttonEditar = tkinter.Button(bottomframe, text="Editar",font='Arial 8 bold', command = lambda:EditarFunc(rootConsFunc))
    buttonEditar.place(x=330,y=350)
    buttonExcluir = tkinter.Button(bottomframe, text="Excluir",font='Arial 8 bold', command="")
    buttonExcluir.place(x=380,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold',bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootConsFunc))
    buttonSair.place(x=435,y=350)
    rootConsFunc.mainloop()
        
def menuGerente():
    global rootGerente, buttonCadFuncionario, buttonConsFuncionario, buttonExit
   
    rootGerente =tkinter.Tk()
    rootGerente.geometry("600x450")
    rootGerente.configure(background="#98FB98")
    rootGerente.resizable(width=False, height=False)
    rootGerente.title("Clínica Vida Plena - Gerente")
    
    topframe = tkinter.Frame(rootGerente,bg='#98FB98')
    topframe.pack(pady=10)

    bottomframe = tkinter.Frame(rootGerente,bg='#98FB98')
    bottomframe.pack(pady=10)
   
    heading = tkinter.Label(topframe, text="Gerenciamento de Funcionarios", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
   

    buttonCadFuncionario = tkinter.Button(bottomframe, text="Cadastrar Funcionario",font='Arial 12 bold',command=lambda: CadastrarFunc(rootGerente))
    buttonConsFuncionario = tkinter.Button(bottomframe, text="Consultar Funcionario",font='Arial 12 bold',command=lambda:ConsultarFunc(rootGerente))
    buttonExit = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootGerente))
    heading.pack(pady=5)
  
    buttonCadFuncionario.pack(pady=10)
    buttonConsFuncionario.pack(pady=10)
    buttonExit.pack(pady=30)

    rootGerente.title("Clínica Vida Plena - Funcionarios")
    rootGerente.mainloop()


# if __name__ == "__main__":
#     menuGerente()
