import sqlite3

def init_db():
    conn = sqlite3.connect('clinic.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS patients (
                 id INTEGER PRIMARY KEY,
                 name TEXT NOT NULL,
                 dob DATE NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS appointments (
                 id INTEGER PRIMARY KEY,
                 patient_id INTEGER,
                 date DATE NOT NULL,
                 time TIME NOT NULL,
                 doctor_name TEXT NOT NULL,
                 FOREIGN KEY(patient_id) REFERENCES patients(id))''')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()