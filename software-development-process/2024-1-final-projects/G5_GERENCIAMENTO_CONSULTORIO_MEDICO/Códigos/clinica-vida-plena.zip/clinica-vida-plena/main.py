import tkinter
from login import *
from windowGerente import *
from windowMedico import *
from windowRecepcionista import *
import subprocess

subprocess.Popen(["python", "app.py"])



Entry()