from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('clinic.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/patients', methods=['POST'])
def add_patient():
    data = request.json
    conn = get_db_connection()
    conn.execute('INSERT INTO patients (name, dob) VALUES (?, ?)',
                 (data['name'], data['dob']))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

@app.route('/appointments', methods=['POST'])
def add_appointment():
    data = request.json
    conn = get_db_connection()
    conn.execute('INSERT INTO appointments (patient_id, date, time, doctor_name) VALUES (?, ?, ?, ?)',
                 (data['patient_id'], data['date'], data['time'], data['doctor_name']))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

if __name__ == '__main__':
    app.run(debug=True)