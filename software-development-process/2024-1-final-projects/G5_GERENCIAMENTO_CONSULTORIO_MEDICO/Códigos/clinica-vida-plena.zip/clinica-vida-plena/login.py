import tkinter
from windowGerente import menuGerente
from windowMedico import menuMedico
from windowRecepcionista import menuRecepcionista


def GET():
    global userbox, passbox, error, rootLogin 
    S1 = userbox.get()
    S2 = passbox.get()
    S3 = cargo_var.get()

    if (S1== 'admin' and S2=='123' and S3== 'Gerente'): #acesso Gerente
        rootLogin.destroy()
        menuGerente()
    elif (S1== 'Med1' and S2=='123' and S3== 'Médico(a)'): #acesso Médico
        rootLogin.destroy()
        menuMedico()
    elif (S1== 'Recep1' and S2=='123' and S3== 'Recepcionista'): #acesso Recpcionista
        rootLogin.destroy()
        menuRecepcionista()
    
    else:
        error = tkinter.Label(bottomframe, text="Credenciais inválidas, tente novamente !!!", fg="red",font="Times 12 bold")
        error.pack()
    

def Entry(): #tela de login
    global userbox, passbox, login, topframe, bottomframe, rootLogin,cargo_var  
    rootLogin = tkinter.Tk()
    rootLogin.geometry("500x300")
    rootLogin.configure(background="#98FB98")
    rootLogin.resizable(width=False, height=False)
    topframe = tkinter.Frame(rootLogin,bg='#98FB98') #topframe vai ser um elemento (frame) que sera inserido no root(formulario)
    topframe.pack(pady=10)

    bottomframe = tkinter.Frame(rootLogin,bg='#98FB98')
    bottomframe.pack(pady=10)

    headingLogin = tkinter.Label(topframe, text="Clínica Vida Plena", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    
    username = tkinter.Label(topframe, text=" Usuário:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    userbox = tkinter.Entry(topframe)

    password = tkinter.Label(bottomframe, text="Senha:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    passbox = tkinter.Entry(bottomframe, show="*")

    cargo_var = tkinter.StringVar()
    cargo_var.set("Cargo")
    cargo = tkinter.OptionMenu(bottomframe, cargo_var, "Gerente", "Recepcionista", "Médico(a)")

    login = tkinter.Button(bottomframe, text="LOGIN",font='Arial 8 bold',command=GET)

      
    headingLogin.pack(pady=5)
    username.pack(pady=3)
    userbox.pack(pady=3)
    password.pack()
    passbox.pack(pady=3)
    cargo.pack(pady=3)
    login.pack(pady=15)
    
    rootLogin.title("Clínica Vida Plena - Login")
    rootLogin.mainloop()

# if __name__ == "__main__":
#     Entry()
