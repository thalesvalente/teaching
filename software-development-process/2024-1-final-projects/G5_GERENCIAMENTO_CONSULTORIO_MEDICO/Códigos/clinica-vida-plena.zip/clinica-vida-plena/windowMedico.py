import tkinter
import sqlite3
import tkinter.messagebox
from tkinter import messagebox
import tkinter as tk
from tkinter import ttk


def voltar(root):
    # Chamar a função menuMedico e destruir a janela atual
    root.destroy()
    menuMedico()

def SairSistema(root):
    # Chamar a função menuMedico e destruir a janela atual
    root.destroy()
    from login import Entry
    Entry()    

def mensagem(title="", message="", root=None):
    messagebox.showinfo(title=title, message=message)  
    if root is not None:
        root.destroy()
    menuMedico()

def iniciarConsulta(root):
      
    global root_ConsMed, namebox, name, prescricao, prescricaobox, Id_Atendimento, Id_Atendimentobox, data,databox, Id_Consulta, Id_Consultabox, buttonVoltar,buttonFimConsMed, buttonSair
    root.destroy()
    root_ConsMed = tkinter.Tk()
    root_ConsMed.geometry("600x450")
    root_ConsMed.configure(background="#98FB98")
    root_ConsMed.resizable(width=False, height=False)
    root_ConsMed.title("Clínica Vida Plena - Consulta Médica de Paciente")
    
    topframe = tkinter.Frame(root_ConsMed, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(root_ConsMed, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Consulta Médica de Paciente", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    
    Id_Consulta = tkinter.Label(bottomframe, text="Id Consulta:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    Id_Consulta.place(x=50, y=20)  
    Id_Consultabox = tkinter.Entry(bottomframe, width=10)
    Id_Consultabox.place(x=140, y=20)  

    Id_Atendimento = tkinter.Label(bottomframe, text="Id Atendimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    Id_Atendimento.place(x=215, y=20)  
    Id_Atendimentobox = tkinter.Entry(bottomframe, width=10)
    Id_Atendimentobox.place(x=328, y=20)  

    data = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    data.place(x=390, y=20)  
    databox = tkinter.Entry(bottomframe, width=15)
    databox.place(x=435, y=20)
    
    name = tkinter.Label(bottomframe, text="Nome Paciente:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=61)
    namebox.place(x=160, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    prescricao = tkinter.Label(bottomframe, text="Prescrição Médica:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    prescricao.place(x=50, y=120)  # Define a posição do label 'Nome' no 'bottomframe'
    prescricaobox = tkinter.Text(bottomframe, width=60, height=10)  # Usando Text para permitir múltiplas linhas e definir altura
    prescricaobox.place(x=50, y=145)


    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(root_ConsMed))
    buttonVoltar.place(x=265,y=350)
    buttonFimConsMed = tkinter.Button(bottomframe, text="Finalizar Consulta",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: mensagem("", "Consulta Realizada !",root_ConsMed))
    buttonFimConsMed.place(x=320,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(root_ConsMed))
    buttonSair.place(x=435,y=350)
    root_ConsMed.mainloop()

def EditarConsulta(root):
      
    global root_editarConsulta, namebox, name, prescricao, prescricaobox, Id_Atendimento, Id_Atendimentobox, data,databox, Id_Consulta, Id_Consultabox, buttonVoltar,buttonFimConsMed, buttonSair
    root.destroy()
    root_editarConsulta = tkinter.Tk()
    root_editarConsulta.geometry("600x450")
    root_editarConsulta.configure(background="#98FB98")
    root_editarConsulta.resizable(width=False, height=False)
    root_editarConsulta.title("Clínica Vida Plena - Edição de Consulta Médica")
    
    topframe = tkinter.Frame(root_editarConsulta, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(root_editarConsulta, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Edição de Consulta Médica", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    
    Id_Consulta = tkinter.Label(bottomframe, text="Id Consulta:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    Id_Consulta.place(x=50, y=20)  
    Id_Consultabox = tkinter.Entry(bottomframe, width=10)
    Id_Consultabox.place(x=140, y=20)  

    Id_Atendimento = tkinter.Label(bottomframe, text="Id Atendimento:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    Id_Atendimento.place(x=215, y=20)  
    Id_Atendimentobox = tkinter.Entry(bottomframe, width=10)
    Id_Atendimentobox.place(x=328, y=20)  

    data = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    data.place(x=390, y=20)  
    databox = tkinter.Entry(bottomframe, width=15)
    databox.place(x=435, y=20)
    
    name = tkinter.Label(bottomframe, text="Nome Paciente:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    name.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    namebox = tkinter.Entry(bottomframe, width=61)
    namebox.place(x=160, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    prescricao = tkinter.Label(bottomframe, text="Prescrição Médica:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    prescricao.place(x=50, y=120)  # Define a posição do label 'Nome' no 'bottomframe'
    prescricaobox = tkinter.Text(bottomframe, width=60, height=10)  # Usando Text para permitir múltiplas linhas e definir altura
    prescricaobox.place(x=50, y=145)

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(root_editarConsulta))
    buttonVoltar.place(x=265,y=350)
    buttonFimConsMed = tkinter.Button(bottomframe, text="Salvar Alterações",font='Arial 8 bold', bg='#00FF00' , fg='#006400', command=lambda: mensagem("", "Consulta Atualizada !",root_editarConsulta))
    buttonFimConsMed.place(x=320,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(root_editarConsulta))
    buttonSair.place(x=437,y=350)
    root_ConsMed.mainloop()

def ConsultAtendim(root):       
    global rootConsAtend, datebox,buttonVoltar,buttonCadastrar, buttonSair, buttonListAtend,buttonInicioConsult
    root.destroy()
    rootConsAtend = tkinter.Tk()
    rootConsAtend.geometry("600x450")
    rootConsAtend.configure(background="#98FB98")
    rootConsAtend.resizable(width=False, height=False)
    rootConsAtend.title("Clínica Vida Plena - Atendimentos")
    
    topframe = tkinter.Frame(rootConsAtend, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootConsAtend, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCad = tkinter.Label(topframe, text="Atendimentos Agendados", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCad.place(relx=0.5, rely=0.5, anchor='center')  # Posiciona o label dentro do topframe

    date = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    date.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    datebox = tkinter.Entry(bottomframe, width=30)
    datebox.place(x=100, y=70)  # Define a posição do 'Entry' no 'bottomframe'
        
    buttonListAtend = tkinter.Button(bottomframe, text="Pesquisar",font='Arial 9 bold',command="")
    buttonListAtend.place(x=300, y=68)
    
    columns = ("ID", "Nome", "Data","Hora", "Médico Responsável")
    tree = ttk.Treeview(bottomframe, columns=columns, show='headings')
    
    tree.column("ID", width=30, anchor='center')
    tree.column("Nome", width=150)
    tree.column("Data", width=60, anchor='center')
    tree.column("Hora", width=60, anchor='center')
    tree.column("Médico Responsável", width=100)

    
    tree.heading("ID", text="ID")
    tree.heading("Nome", text="Nome")
    tree.heading("Data", text="Data")
    tree.heading("Hora", text="Hora")

    tree.heading("Médico Responsável", text="Médico Responsável")
    tree.place(x=50, y=100, width=500, height=200)

    # Exemplo de inserção de dados na tabela
    tree.insert("", "end", values=("1", "Jose Silva", "31/03/2024", "10:00", "Ana Souza" ))
    tree.insert("", "end", values=("2", "Beatriz Oliveira", "22/01/2024", "11:00", "Clara Oliveira"))
    tree.insert("", "end", values=("3", "Diogo Sousa", "22/01/2024", "11:50", "Isabela Lima"))

    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootConsAtend))
    buttonVoltar.place(x=280,y=350)
    
    buttonInicioConsult = tkinter.Button(bottomframe, text="Iniciar Consulta",font='Arial 8 bold',command=lambda: iniciarConsulta(rootConsAtend))
    buttonInicioConsult.place(x=330,y=350)
    
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold',bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootConsAtend))
    buttonSair.place(x=435,y=350)
    rootConsAtend.mainloop()

 

def ConsultasMedList(root):
    global rootConsMedList, buttonVoltar,buttonEditar, buttonExcluir, buttonSair,buttonListConsultas
    root.destroy()
    rootConsMedList =tkinter.Tk()
    rootConsMedList.geometry("600x450")
    rootConsMedList.configure(background="#98FB98")
    rootConsMedList.resizable(width=False, height=False)
    rootConsMedList.title("Clínica Vida Plena - Consultas Médicas")
    
    topframe = tkinter.Frame(rootConsMedList, bg='#98FB98')
    topframe.place(relx=0, rely=0, relwidth=1, relheight=0.1)  # Posiciona o frame no topo

    bottomframe = tkinter.Frame(rootConsMedList, bg='#98FB98')
    bottomframe.place(relx=0, rely=0.1, relwidth=1, relheight=0.9)  # Posiciona o frame no fundo

    headingCons = tkinter.Label(topframe, text="Consultas Médicas", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
    headingCons.place(relx=0.5, rely=0.5, anchor='center')
     

    date = tkinter.Label(bottomframe, text="Data:", bg='#98FB98', fg='#4F4F4F', font='Times 12 bold')
    date.place(x=50, y=70)  # Define a posição do label 'Nome' no 'bottomframe'
    datebox = tkinter.Entry(bottomframe, width=30)
    datebox.place(x=100, y=70)  # Define a posição do 'Entry' no 'bottomframe'

    buttonListConsultas = tkinter.Button(bottomframe, text="Pesquisar",font='Arial 10 bold',command="")
    buttonListConsultas.place(x=300, y=68)

    #configuração da tabela de atendimentos
    columns = ("ID-Consulta", "ID-Atendimento","Nome","Data","Prescrição")
    tree = ttk.Treeview(bottomframe, columns=columns, show='headings')
    
    tree.column("ID-Consulta", width=70)
    tree.column("ID-Atendimento", width=60)
    tree.column("Nome", width=100)
    tree.column("Data", width=70)      
    tree.column("Prescrição", width=150)

    
    tree.heading("ID-Consulta", text="ID-Consulta")
    tree.heading("ID-Atendimento", text="ID-Atend.")
    tree.heading("Nome", text="Nome")
    tree.heading("Data", text="Data")    
    tree.heading("Prescrição", text="Prescrição Médica")
    
    tree.place(x=50, y=100, width=500, height=200)

    # Exemplo de inserção de dados na tabela
    tree.insert("", "end", values=("1", "101", "Alice Silva", "15-01-2024", "Gripe comum; Tratamento: Repouso, hidratação, e uso de medicamentos sintomáticos;Remédio: Paracetamol 500 mg, tomar 1 comprimido a cada 6 horas por 5 dias"))
    tree.insert("", "end", values=("2", "102", "Bruno Costa", "16-01-2024", "Dor muscular; Tratamento: Aplicação de calor local, fisioterapia, e anti-inflamatórios; Remédio: Ibuprofeno 600 mg, tomar 1 comprimido a cada 8 horas por 7 dias"))
    tree.insert("", "end", values=("3", "103", "Carla Nunes", "17-01-2024", "Infecção urinária; Tratamento: Antibiótico e aumento da ingestão de líquidos; Remédio: Amoxicilina 500 mg, tomar 1 comprimido a cada 8 horas por 10 dias"))
    tree.insert("", "end", values=("4", "104", "Daniel Souza", "18-01-2024", "Diabetes tipo 2; Tratamento: Controle alimentar, exercícios físicos, e hipoglicemiante oral; Remédio: Metformina 500 mg, tomar 1 comprimido após o jantar por 30 dias"))
    tree.insert("", "end", values=("5", "105", "Elena Torres", "19-01-2024", "Hipertensão arterial; Tratamento: Redução de sal na dieta, controle de peso, e anti-hipertensivo; Remédio: Losartana 50 mg, tomar 1 comprimido pela manhã por 30 dias"))
    tree.insert("", "end", values=("6", "106", "Fabio Almeida", "20-01-2024", "Alergia respiratória; Tratamento: Evitar alérgenos e uso de anti-histamínico; Remédio: Loratadina 10 mg, tomar 1 comprimido à noite por 14 dias"))
    tree.insert("", "end", values=("7", "107", "Gabriela Melo", "21-01-2024", "Asma; Tratamento: Uso de broncodilatador e corticosteroide inalatório; Remédio: Salbutamol spray, inalar 2 jatos a cada 6 horas quando necessário por 30 dias"))
    tree.insert("", "end", values=("8", "108", "Henrique Lima", "22-01-2024", "Infecção de garganta; Tratamento: Antibiótico e repouso vocal; Remédio: Azitromicina 500 mg, tomar 1 comprimido ao dia por 3 dias"))
    tree.insert("", "end", values=("9", "109", "Isabela Rocha", "23-01-2024", "Gastrite; Tratamento: Dieta leve, evitar alimentos irritantes, e uso de inibidor de bomba de prótons; Remédio: Omeprazol 20 mg, tomar 1 cápsula pela manhã em jejum por 14 dias"))
    tree.insert("", "end", values=("10", "110", "João Marques", "24-01-2024", "Otite média; Tratamento: Antibiótico e analgésico; Remédio: Amoxicilina 875 mg, tomar 1 comprimido a cada 12 horas por 7 dias"))

    #configuração dos botoes
    buttonVoltar = tkinter.Button(bottomframe, text="Voltar",font='Arial 8 bold',command=lambda: voltar(rootConsMedList))
    buttonVoltar.place(x=280,y=350)
    buttonEditar = tkinter.Button(bottomframe, text="Editar",font='Arial 8 bold', command = lambda:EditarConsulta(rootConsMedList))
    buttonEditar.place(x=330,y=350)
    buttonExcluir = tkinter.Button(bottomframe, text="Excluir",font='Arial 8 bold', command=lambda: mensagem("", "Consulta Excluída !",rootConsMedList))
    buttonExcluir.place(x=380,y=350)
    buttonSair = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold',bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootConsMedList))
    buttonSair.place(x=435,y=350)
    rootConsMedList.mainloop()
        
def menuMedico():
    global rootMedico, buttonAtendimentos, buttonConsPac, buttonExit
   
    rootMedico =tkinter.Tk()
    rootMedico.geometry("600x450")
    rootMedico.configure(background="#98FB98")
    rootMedico.resizable(width=False, height=False)
    rootMedico.title("Clínica Vida Plena - Médico(a)")
    
    topframe = tkinter.Frame(rootMedico,bg='#98FB98')
    topframe.pack(pady=10)

    bottomframe = tkinter.Frame(rootMedico,bg='#98FB98')
    bottomframe.pack(pady=10)
   
    heading = tkinter.Label(topframe, text="Atendimento/Consulta ", bg='#98FB98', fg='#4F4F4F', font='Times 16 bold')
   

    buttonAtendimentos = tkinter.Button(bottomframe, text="Atendimentos",font='Arial 12 bold',command=lambda: ConsultAtendim(rootMedico))
    buttonConsPac = tkinter.Button(bottomframe, text="Consultas Médicas",font='Arial 12 bold',command=lambda:ConsultasMedList(rootMedico))
    buttonExit = tkinter.Button(bottomframe, text="Sair da Conta",font='Arial 8 bold', bg='#FF0000' , fg='#FFFFFF', command=lambda: SairSistema(rootMedico)) 
    heading.pack(pady=5)
  
    buttonAtendimentos.pack(pady=10)
    buttonConsPac.pack(pady=10)
    buttonExit.pack(pady=30)

    rootMedico.title("Clínica Vida Plena - Médico(a)")
    rootMedico.mainloop()


# if __name__ == "__main__":
#     menuMedico()