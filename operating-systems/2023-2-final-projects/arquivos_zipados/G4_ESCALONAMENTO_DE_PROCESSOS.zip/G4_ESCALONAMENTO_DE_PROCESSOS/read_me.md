﻿Reconhecimentos e Direitos Autorais

@autor: [Filipe Correia Belfort, Josiel Costa dos Santos Junior e Steven Roger dos Santos Soares]

@contato: [filipe.belfort@discente.ufma.br, josiel.junior@discente.ufma.br e steven.roger@discente.ufma.br]

@data ﾃｺltima versﾃ｣o: [10-12-2023]

@versﾃ｣o: 1.0

@outros repositﾃｳrios: [URLs - https://github.com/Josiel-Jr]

@Agradecimentos: Universidade Federal do Maranhﾃ｣o (UFMA), Professor Doutor Thales Levi Azevedo Valente, e colegas de curso.

@Copyright/License

Este material ﾃｩ resultado de um trabalho acadﾃｪmico para a disciplina SISTEMAS OPERACIONAIS, sobre a orientaﾃｧﾃ｣o do professor Dr. THALES LEVI AZEVEDO VALENTE, semestre letivo 2023.2, curso Engenharia da Computaﾃｧﾃ｣o, na Universidade Federal do Maranhﾃ｣o (UFMA). Todo o material sob esta licenﾃｧa ﾃｩ software livre: pode ser usado para fins acadﾃｪmicos e comerciais sem nenhum custo. Nﾃ｣o hﾃ｡ papelada, nem royalties, nem restriﾃｧﾃｵes de "copyleft" do tipo GNU. Ele ﾃｩ licenciado sob os termos da licenﾃｧa MIT reproduzida abaixo e, portanto, ﾃｩ compatﾃｭvel com GPL e tambﾃｩm se qualifica como software de cﾃｳdigo aberto. ﾃ・de domﾃｭnio pﾃｺblico. Os detalhes legais estﾃ｣o abaixo. O espﾃｭrito desta licenﾃｧa ﾃｩ que vocﾃｪ ﾃｩ livre para usar este material para qualquer finalidade, sem nenhum custo. O ﾃｺnico requisito ﾃｩ que, se vocﾃｪ usﾃ｡-los, nos dﾃｪ crﾃｩdito.

Copyright ﾂｩ 2023 Educational Material

Este material estﾃ｡ licenciado sob a Licenﾃｧa MIT. ﾃ・permitido o uso, cﾃｳpia, modificaﾃｧﾃ｣o, e distribuiﾃｧﾃ｣o deste material para qualquer fim, desde que acompanhado deste aviso de direitos autorais.

O MATERIAL ﾃ・FORNECIDO "COMO ESTﾃ・, SEM GARANTIA DE QUALQUER TIPO, EXPRESSA OU IMPLﾃ垢ITA, INCLUINDO, MAS Nﾃグ SE LIMITANDO ﾃS GARANTIAS DE COMERCIALIZAﾃ・グ, ADEQUAﾃ・グ A UM DETERMINADO FIM E Nﾃグ VIOLAﾃ・グ. EM HIPﾃ典ESE ALGUMA OS AUTORES OU DETENTORES DE DIREITOS AUTORAIS SERﾃグ RESPONSﾃ〃EIS POR QUALQUER RECLAMAﾃ・グ, DANOS OU OUTRA RESPONSABILIDADE, SEJA EM UMA Aﾃ・グ DE CONTRATO, ATO ILﾃ垢ITO OU DE OUTRA FORMA, DECORRENTE DE, OU EM CONEXﾃグ COM O MATERIAL OU O USO OU OUTRAS NEGOCIAﾃ・髭S NO MATERIAL.

Para mais informaﾃｧﾃｵes sobre a Licenﾃｧa MIT: https://opensource.org/licenses/MIT.
